const { MessageType, Mimetype } = require("@adiwajshing/baileys");
const chalk = require("chalk");
const inputSanitization = require("../sidekick/input-sanitization");
const strings = require("../lib/db")
const CREATE = strings.create;

module.exports = {
    name: "create",
    description: CREATE.DESCRIPTION,
    extendedDescription: CREATE.EXTENDED_DESCRIPTION,
    demo: { isEnabled: false },
    async handle(client, chat, BotsApp, args) {
        try{
            if(args.length === 0) {
                client.sendMessage(BotsApp.chatId, CREATE.NO_TEXT, MessageType.text);
                return;
            }
            let nameOfTheGrp = 
            BotsApp.body.replace(
                BotsApp.body[0] + BotsApp.commandName + " ",
                ""
            );

            if(BotsApp.isPm) {
                const group = await client.groupCreate (nameOfTheGrp, [BotsApp.owner, BotsApp.sender]);
                client.sendMessage(BotsApp.chatId, CREATE.GROUP_CREATED, MessageType.text);
                return;
            }
            else {
                if(BotsApp.isReply){
                        const group = await client.groupCreate (nameOfTheGrp, [BotsApp.sender, BotsApp.replyParticipant]);
                        client.sendMessage(BotsApp.chatId, CREATE.GROUP_CREATED, MessageType.text);
                        return;
                }
                else {
                    client.sendMessage(BotsApp.chatId, CREATE.TAG_PERSON, MessageType.text);
                    return;
                }
            }
        }

        catch(err) {
            await inputSanitization.handleError(err, client, BotsApp);
        }
    }
}